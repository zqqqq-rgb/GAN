# Online Resource 1

Indexed numerical records for the MVA manuscript. Start with INDEX.json.

- cable/: fixed-budget statistics, per-run values, sampling and bootstrap records.
- neu_det/ and gc10_det/: external comparator statistics and preparation manifests.
- audits/: source/checkpoint metadata, strict-batch timings, corrected Fig8 estimands, annotation review addendum.
- environment/: recorded dependency snapshot and published-code source hashes.
- figures/: numeric Fig8 SVG.

Private cable filenames are replaced with content-hash IDs. No images or weights are included; exact retraining requires legally obtained source data and checkpoints. Cached numerical outcomes support audit, not independent certification of acquisition truth. Two reviewers were author-confirmed but only one shared summary was retained; no independent second original is supplied. The historical one-reviewer audit is preserved and superseded only by the explicit review addendum. Historical source snapshots support the archived BatchNorm configuration (see audits/batchnorm_provenance_addendum.json). The original rationale and per-run normalization attributes were not recorded. The earlier audit is preserved as a historical record.

Code is available at https://github.com/zqqqq-rgb/GAN. Obtain the datasets from their original sources under their applicable terms. These materials have not been uploaded to a journal or repository by this revision task.

Revision addendum 14 October 2026: configurations/ contains 320 archived strict detector args.yaml snapshots with anonymized local roots. cable/q3_resampling_comparisons.csv explicitly indexes all eight augmentation comparisons against the fixed resampling control. audits/qualitative_layout_20261014.json records the unchanged deterministic sample selection used to re-layout Figures 6 and 7. No experimental results, training weights, or original dataset images were changed.
